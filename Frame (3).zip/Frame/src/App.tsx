import { useEffect, FC, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';
import { ThemeProvider, createTheme, CssBaseline } from '@mui/material';
import { Box, TextField, Button, Typography } from '@mui/material';

// Create theme
const theme = createTheme();

// iPhone Frame Component
const IPhoneFrame: FC = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('authenticated', 'true');
    navigate('/home');
  };

  const handleLogout = () => {
    localStorage.removeItem('authenticated');
    navigate('/');
  };

  return (
    <div style={styles.frameMover}>
      <div style={styles.IphoneFrame}>
        <div style={styles.dynamicIsland} />
        <div style={styles.screenContent}>
          <ThemeProvider theme={theme}>
            <CssBaseline />
            <Routes>
              <Route path="/" element={
                <Box component="form" onSubmit={handleSignIn} sx={styles.form}>
                  <Typography variant="h5" gutterBottom sx={styles.title}>
                    Sign In
                  </Typography>
                  <TextField
                    label="Email"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    sx={styles.input}
                  />
                  <TextField
                    label="Password"
                    type="password"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    sx={styles.input}
                  />
                  <Button
                    type="submit"
                    variant="contained"
                    color="primary"
                    fullWidth
                    sx={styles.button}
                  >
                    Sign In
                  </Button>
                </Box>
              }/>
              <Route path="/home" element={<HomePage onLogout={handleLogout} />} />
            </Routes>
          </ThemeProvider>
        </div>
        <div style={styles.homeIndicator} />
      </div>
    </div>
  );
};

// Home Page Component
const HomePage: FC<{ onLogout: () => void }> = ({ onLogout }) => {
  useEffect(() => {
    if (!localStorage.getItem('authenticated')) onLogout();
  }, [onLogout]);

  return (
    <Box sx={styles.homeContainer}>
      <Typography variant="h4" sx={styles.welcomeText}>
        Welcome! 🎉
      </Typography>
      <Button 
        variant="contained" 
        onClick={onLogout} 
        sx={styles.logoutButton}
      >
        Log Out
      </Button>
    </Box>
  );
};

// Main App Component
export default function App() {
  return (
    <Router>
      <IPhoneFrame />
    </Router>
  );
}

// Styles
const styles = {
  frameMover: {
    position: 'fixed',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%) scale(0.8)',
    zIndex: 1000
  },
  IphoneFrame: {
    width: '375px',
    height: '812px',
    backgroundColor: '#000',
    borderRadius: '50px',
    boxShadow: '0 0 0 12px #1a1a1a, 0 0 50px rgba(0,0,0,0.3)',
    overflow: 'hidden',
    position: 'relative' as const,
    backgroundImage: `linear-gradient(rgba(255,255,255,0.65), rgba(255,255,255,0.65)), url('https://wallpapercave.com/wp/wp6229422.jpg')`,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat'
  },
  dynamicIsland: {
    position: 'absolute',
    top: '15px',
    left: '50%',
    transform: 'translateX(-50%)',
    width: '120px',
    height: '35px',
    backgroundColor: '#000',
    borderRadius: '20px',
    zIndex: 2
  },
  screenContent: {
    position: 'absolute',
    top: '8px',
    left: '8px',
    right: '8px',
    bottom: '8px',
    borderRadius: '42px',
    overflow: 'hidden',
    display: 'flex',
    flexDirection: 'column' as const,
  },
  form: {
    flex: 1,
    padding: '40px 20px',
    display: 'flex',
    flexDirection: 'column' as const,
    justifyContent: 'center'
  },
  title: {
    textAlign: 'center' as const,
    marginBottom: '40px',
    color: '#1976d2'
  },
  input: {
    backgroundColor: 'white',
    borderRadius: '8px',
    '& .MuiOutlinedInput-root': {
      borderRadius: '8px'
    }
  },
  button: {
    marginTop: '30px',
    padding: '15px 0',
    borderRadius: '8px',
    fontSize: '16px'
  },
  homeContainer: {
    flex: 1,
    padding: '40px 20px',
    display: 'flex',
    flexDirection: 'column' as const,
    alignItems: 'center',
    justifyContent: 'center'
  },
  welcomeText: {
    color: '#1976d2',
    marginBottom: '40px',
    fontWeight: 'bold'
  },
  logoutButton: {
    padding: '12px 40px',
    borderRadius: '8px',
    fontSize: '16px',
    backgroundColor: '#ff4444',
    '&:hover': {
      backgroundColor: '#cc0000'
    }
  },
  homeIndicator: {
    position: 'absolute',
    bottom: '12px',
    left: '50%',
    transform: 'translateX(-50%)',
    width: '110px',
    height: '4px',
    backgroundColor: 'rgba(0,0,0,0.2)',
    borderRadius: '4px',
    backdropFilter: 'blur(4px)'
  }
} as const;